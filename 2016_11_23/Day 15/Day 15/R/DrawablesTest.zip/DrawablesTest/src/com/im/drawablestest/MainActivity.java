package com.im.drawablestest;

import android.support.v7.app.ActionBarActivity;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class MainActivity extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		RelativeLayout rl = (RelativeLayout) findViewById(R.id.frame);
		
		//Image Drawable
		ImageView iv = new ImageView(this);
		//Drawable drawable = getResources().getDrawable(R.drawable.bubble);
		//iv.setImageDrawable(drawable);
		
		
		
		//Color Drawable
		ColorDrawable cd = new ColorDrawable(0xffff0000);
		cd = new ColorDrawable(Color.parseColor("#FFEDCACA"));
		cd.setAlpha(110);
		iv.setImageDrawable(cd);

		
		
		
		
		
		
		//Shape Drawable
		ShapeDrawable shape1 = new ShapeDrawable(new OvalShape());
		shape1.getPaint().setColor(Color.MAGENTA);
		shape1.setIntrinsicHeight(200);
		shape1.setIntrinsicWidth(200);
		shape1.setAlpha(127);
		
		ImageView iv1 = new ImageView(this);
		iv1.setImageDrawable(shape1);
		
		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(200, 200);
		params.addRule(RelativeLayout.CENTER_IN_PARENT);
		params.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
		iv1.setLayoutParams(params);
		
		
		
		ShapeDrawable shape2 = new ShapeDrawable(new OvalShape());
		shape2.getPaint().setColor(Color.CYAN);
		shape2.setIntrinsicHeight(200);
		shape2.setIntrinsicWidth(200);
		shape2.setAlpha(127);
		
		ImageView iv2 = new ImageView(this);
		iv2.setImageDrawable(shape2);
		
		RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams(200, 200);
		params2.addRule(RelativeLayout.CENTER_IN_PARENT);
		params2.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
		iv2.setLayoutParams(params2);
		
		
		
		

		rl.addView(iv);
		rl.addView(iv1);
		rl.addView(iv2);
	}

	
}
