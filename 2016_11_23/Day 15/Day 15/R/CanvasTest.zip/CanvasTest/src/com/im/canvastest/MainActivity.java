package com.im.canvastest;



import java.util.Random;

import android.support.v7.app.ActionBarActivity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;

public class MainActivity extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		RelativeLayout rl = (RelativeLayout) findViewById(R.id.frame);
		Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.bubble);
		final BubbleView bView = new BubbleView(this, bitmap);
		rl.addView(bView);
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				while(bView.move()){
					bView.postInvalidate();
					try {
						Thread.sleep(100);
					} catch (Exception e) {
						
					}
				}
				
			}
		}).start();
		
	}

	
	class BubbleView extends View{
		Bitmap bitmap;
		Paint paint = new Paint();
		Random random = new Random();
		int x =50,y=50;
		public BubbleView(Context context, Bitmap bitmap) {
			super(context);
			this.bitmap =  Bitmap.createScaledBitmap(bitmap, 200, 200, false);
		}
		
		@Override
		protected void onDraw(Canvas canvas) {
			canvas.drawBitmap(bitmap, x, y, paint);
		}
		
		public boolean move(){
			x+=random.nextInt(5);
			y+=random.nextInt(5);
			return true;
		}
		
	}
	
	
}
