/** Automatically generated file. DO NOT MODIFY */
package com.im.canvastest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}