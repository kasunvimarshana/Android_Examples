/** Automatically generated file. DO NOT MODIFY */
package com.im.surfaceviewtest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}