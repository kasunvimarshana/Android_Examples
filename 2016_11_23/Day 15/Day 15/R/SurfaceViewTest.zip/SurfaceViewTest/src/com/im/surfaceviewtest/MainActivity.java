package com.im.surfaceviewtest;



import java.util.Random;

import android.support.v7.app.ActionBarActivity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.RelativeLayout;

public class MainActivity extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		RelativeLayout rl = (RelativeLayout) findViewById(R.id.frame);
		Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.bubble);
		final BubbleView bView = new BubbleView(this, bitmap);
		rl.addView(bView);
	}

	
}

class BubbleView extends SurfaceView implements SurfaceHolder.Callback{
	Bitmap bitmap;
	Paint paint = new Paint();
	SurfaceHolder surfaceHolder ;
	Thread thread;
	
	int x =50,y=50;
	public BubbleView(Context context, Bitmap bitmap) {
		super(context);
		this.bitmap =  Bitmap.createScaledBitmap(bitmap, 200, 200, false);
		surfaceHolder = getHolder();
		surfaceHolder.addCallback(this);
	}
	
	
	protected void bubbleDraw(Canvas canvas) {
		canvas.drawColor(Color.DKGRAY);
		canvas.drawBitmap(bitmap, x, y, paint);
	}
	
	public boolean move(){
		Random random = new Random();
		int movex = random.nextInt(5);
		int movey = random.nextInt(5);
		x+=movex;
		y+=movey;
		return true;
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		
		
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		thread = new Thread(new Runnable() {
			
			@Override
			public void run() {
				while(!Thread.currentThread().isInterrupted() && move()){
					Canvas canvas = surfaceHolder.lockCanvas();
					if(canvas !=null){
						bubbleDraw(canvas);
						surfaceHolder.unlockCanvasAndPost(canvas);
					}
				}
				
			}
		});
		thread.start();
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		if(thread!=null){
			thread.interrupt();
		}
	}
	
}
